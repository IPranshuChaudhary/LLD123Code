package DesignPatterns.observer;

public interface OrderPlacedSubscriber {

    void announceOrderPlaced();
}
