package DesignPatterns.strategy;

public class BikePathCalculatorStrategy implements PathCalculatorStrategy {

    @Override
    public void findPath(String from, String to) {

    }
}
