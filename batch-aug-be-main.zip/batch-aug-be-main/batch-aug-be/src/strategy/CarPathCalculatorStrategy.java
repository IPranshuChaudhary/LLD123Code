package DesignPatterns.strategy;

public class CarPathCalculatorStrategy implements PathCalculatorStrategy {

    @Override
    public void findPath(String from, String to) {

    }
}
