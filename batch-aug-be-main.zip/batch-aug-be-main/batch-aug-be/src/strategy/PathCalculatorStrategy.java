package DesignPatterns.strategy;

public interface PathCalculatorStrategy {

    void findPath(String from, String to);
}
