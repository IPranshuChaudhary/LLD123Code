package com.example.bookmyshowsep23.models;

public enum ScreenFeatures {
    TWO_D, // 1
    THREE_D, // 2
    DOLBY, // 3
    IMAX // 4
}
