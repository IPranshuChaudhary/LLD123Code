package com.example.bookmyshowsep23.models;

public enum BookingStatus {
    SUCCESS,
    FAILURE
}
