package com.example.bookmyshowsep23.models;

public enum PaymentProvider {
    RAZORPAY,
    PAYU
}
