package com.example.bookmyshowsep23.models;

public enum SeatStatus {
    AVAILABLE,
    OCCUPIED,
    UNAVAILABLE,
    BLOCKED,
}
