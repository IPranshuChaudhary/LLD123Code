package com.example.bookmyshowsep23.models;

public enum PaymentMethod {
    CREDIT_CARD,
    DEBIT_CARD,
}
