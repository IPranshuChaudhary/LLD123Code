package OS1.Concurrency.AdderSubWithSynchronized;

public class Count {
    int value = 0;
}
