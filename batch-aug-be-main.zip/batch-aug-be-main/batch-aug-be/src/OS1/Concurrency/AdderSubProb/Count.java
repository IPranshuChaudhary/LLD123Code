package OS1.Concurrency.AdderSubProb;

public class Count {
    int value = 0;
}
