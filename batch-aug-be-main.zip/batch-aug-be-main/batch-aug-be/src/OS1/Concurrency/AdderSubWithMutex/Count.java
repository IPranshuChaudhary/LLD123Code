package OS1.Concurrency.AdderSubWithMutex;

public class Count {
    int value = 0;
}
