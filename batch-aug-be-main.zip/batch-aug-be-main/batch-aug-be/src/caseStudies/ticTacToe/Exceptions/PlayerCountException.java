package caseStudies.ticTacToe.Exceptions;

public class PlayerCountException extends Exception{
}
