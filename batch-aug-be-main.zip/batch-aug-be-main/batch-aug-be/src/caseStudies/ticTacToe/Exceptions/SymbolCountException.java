package caseStudies.ticTacToe.Exceptions;

public class SymbolCountException extends Exception{
}
