package caseStudies.ticTacToe.models;

public class Symbol {

    public Symbol(char aChar){
        this.aChar = aChar;
    }

    private char aChar;

    public char getaChar() {
        return aChar;
    }

    public void setaChar(char aChar) {
        this.aChar = aChar;
    }
}
