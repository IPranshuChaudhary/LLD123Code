package caseStudies.ticTacToe.models;

public enum BotDifficultyLevel {
    EASY,
    MEDIUM,
    HARD
}
