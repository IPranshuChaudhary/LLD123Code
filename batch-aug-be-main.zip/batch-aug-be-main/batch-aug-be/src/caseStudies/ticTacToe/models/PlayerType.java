package caseStudies.ticTacToe.models;

public enum PlayerType {
    BOT,
    HUMAN
}
