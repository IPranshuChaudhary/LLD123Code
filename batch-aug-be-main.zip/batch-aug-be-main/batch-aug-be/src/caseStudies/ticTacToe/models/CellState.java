package caseStudies.ticTacToe.models;

public enum CellState {
    EMPTY,
    FILLED
}
