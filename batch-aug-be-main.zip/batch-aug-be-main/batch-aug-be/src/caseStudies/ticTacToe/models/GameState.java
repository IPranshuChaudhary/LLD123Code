package caseStudies.ticTacToe.models;

public enum GameState {
    IN_PROGRESS,
    WIN,
    DRAW
}
