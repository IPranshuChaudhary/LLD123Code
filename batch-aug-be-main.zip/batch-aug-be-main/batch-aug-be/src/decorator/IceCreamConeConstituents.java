package designpatterns.decorator;

public interface IceCreamConeConstituents {

    int getCost();

    String getDescription();
}
