package caseStudies.parkingLot.dto;

public enum ResponseStatus {
    SUCCESS,
    FAILURE
}
