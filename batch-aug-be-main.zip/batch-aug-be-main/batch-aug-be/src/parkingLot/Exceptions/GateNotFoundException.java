package caseStudies.parkingLot.Exceptions;

public class GateNotFoundException extends Exception{
}
