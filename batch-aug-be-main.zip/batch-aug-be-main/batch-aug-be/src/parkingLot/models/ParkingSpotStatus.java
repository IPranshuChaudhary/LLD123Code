package caseStudies.parkingLot.models;

public enum ParkingSpotStatus {
    EMPTY,
    FILLED
}
