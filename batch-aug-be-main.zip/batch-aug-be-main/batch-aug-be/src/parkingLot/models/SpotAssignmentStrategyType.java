package caseStudies.parkingLot.models;

public enum SpotAssignmentStrategyType {
}
