package caseStudies.parkingLot.models;

public enum GateType {
}
