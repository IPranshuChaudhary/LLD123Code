package caseStudies.parkingLot.models;

public enum ParkingLotStatus {
}
