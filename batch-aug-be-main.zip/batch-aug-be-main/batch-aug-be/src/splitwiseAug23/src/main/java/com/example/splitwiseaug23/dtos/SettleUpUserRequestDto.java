package com.example.splitwiseaug23.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SettleUpUserRequestDto {
    private Long userId;
}
