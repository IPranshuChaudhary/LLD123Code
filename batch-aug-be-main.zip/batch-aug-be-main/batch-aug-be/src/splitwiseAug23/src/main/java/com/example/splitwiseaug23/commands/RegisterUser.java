package com.example.splitwiseaug23.commands;

public class RegisterUser implements Command{

    @Override
    public boolean matches(String input) {
        return false;
    }

    @Override
    public void execute(String input) {

    }
}
