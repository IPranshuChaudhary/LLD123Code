package com.example.splitwiseaug23.models;

public enum ExpenseType {
    REGULAR,
    DUMMY
}
