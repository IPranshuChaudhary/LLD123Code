package com.example.splitwiseaug23.controllers;

import com.example.splitwiseaug23.dtos.SettleUpGroupRequestDto;
import com.example.splitwiseaug23.dtos.SettleUpGroupResponseDto;
import com.example.splitwiseaug23.dtos.SettleUpUserRequestDto;
import com.example.splitwiseaug23.dtos.SettleUpUserResponseDto;
import org.springframework.stereotype.Component;

@Component
public class SettleUpController {

    // what should be the request and response here
    public SettleUpUserResponseDto settleUp(SettleUpUserRequestDto request){
        return null;
    }

    public SettleUpGroupResponseDto settleUpGroup(SettleUpGroupRequestDto request){
        return null;
    }
}
