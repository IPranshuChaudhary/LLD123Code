package com.example.splitwiseaug23.dtos;

import com.example.splitwiseaug23.models.Expense;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class SettleUpUserResponseDto {
    private List<Expense> expenses;
}
