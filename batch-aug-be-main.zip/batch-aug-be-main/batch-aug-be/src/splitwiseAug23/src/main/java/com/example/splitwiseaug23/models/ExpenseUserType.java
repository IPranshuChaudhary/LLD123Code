package com.example.splitwiseaug23.models;

public enum ExpenseUserType {
    PAID,
    HAD_TO_PAY
}
