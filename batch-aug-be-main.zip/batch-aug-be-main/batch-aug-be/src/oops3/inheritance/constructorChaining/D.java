package oops3.inheritance.constructorChaining;

public class D extends C{
    public D(){
        super("ABC");
        System.out.println("Constructor of D");
    }
}
