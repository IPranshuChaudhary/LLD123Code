package oops3.inheritance.constructorChaining;

public class Client {
    public static void main(String[] args) {
        D d = new D();
    }
}
