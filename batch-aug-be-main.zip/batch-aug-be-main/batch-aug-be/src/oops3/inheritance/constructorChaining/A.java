package oops3.inheritance.constructorChaining;

public class A {

    public A(int x, String s){
        System.out.println("Constructor of A");
    }
}
