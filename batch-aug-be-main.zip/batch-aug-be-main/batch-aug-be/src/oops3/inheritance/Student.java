package oops3.inheritance;

public class Student extends User{
    double psp;
    void takeATest(){
        System.out.println("Taking a test");
    }

}
