package oops3.inheritance;

public class User {
    String userName;
    void login(){
        System.out.println("We have logged in");
    }
}
