package oops3.polymorphism.compileTime;

public class A {
    String name;
    int age;

    void print(A a){
        System.out.println("I am printing " + a);
    }
}
