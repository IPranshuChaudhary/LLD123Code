package oops3.polymorphism.compileTime;

public class C extends B{
    String companyName;
}
