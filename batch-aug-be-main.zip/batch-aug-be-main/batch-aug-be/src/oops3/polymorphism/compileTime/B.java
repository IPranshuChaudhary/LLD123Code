package oops3.polymorphism.compileTime;

public class B extends A{
    double psp;
}
