package oops3.interfaceCheck;

public class C implements A{

    @Override
    public void run() {
        System.out.println("I am running from C");
    }
}
