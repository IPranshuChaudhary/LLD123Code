package oops3.interfaceCheck;

public class Client {
    public static void main(String[] args) {
        A b = new B();
        A c = new C();
        b.run();
        c.run();
    }
}
