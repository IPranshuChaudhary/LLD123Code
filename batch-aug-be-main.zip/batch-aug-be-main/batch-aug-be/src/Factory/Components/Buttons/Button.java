package DesignPatterns.Factory.Components.Buttons;

public interface Button {
    void changeSize();
}
