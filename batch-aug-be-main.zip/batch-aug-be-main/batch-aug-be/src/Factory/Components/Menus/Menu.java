package DesignPatterns.Factory.Components.Menus;

public interface Menu {
}
