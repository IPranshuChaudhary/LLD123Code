package DesignPatterns.Factory.Components.Menus;

public class IosMenu implements Menu{
}
