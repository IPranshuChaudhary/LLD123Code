package DesignPatterns.Factory.Components.Menus;

public class AndroidMenu implements Menu{
}
