package DesignPatterns.Factory.Components.Dropdowns;

public interface Dropdown {
}
