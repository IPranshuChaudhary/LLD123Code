package DesignPatterns.PrototypeRegistry;

public interface Prototype<T>{
    T clone();
}
