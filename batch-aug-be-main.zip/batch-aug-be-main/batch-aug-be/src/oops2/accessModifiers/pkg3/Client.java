package oops2.accessModifiers.pkg3;

import oops2.accessModifiers.pkg2.StudentChild;

public class Client {
    public static void main(String[] args) {
        StudentChild studentChild = new StudentChild();
//        studentChild.universityName;
//        studentChild.
    }
}
