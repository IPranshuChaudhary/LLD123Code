package oops2.accessModifiers.pkg1;

public class Student {
    private int age;
    String name;
    protected double psp;
    public String universityName;

}
