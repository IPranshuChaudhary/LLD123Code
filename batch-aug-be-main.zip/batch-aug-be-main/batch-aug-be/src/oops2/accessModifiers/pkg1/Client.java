package oops2.accessModifiers.pkg1;

public class Client {
    public static void main(String[] args) {
        Student student = new Student();
        student.psp = 10;
        student.name = "Akash";
        student.universityName = "ABC";
//        student.age = 20;
    }

}
