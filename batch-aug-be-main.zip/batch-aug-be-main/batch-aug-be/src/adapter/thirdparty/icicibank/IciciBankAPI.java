package designpatterns.adapter.thirdparty.icicibank;

public class IciciBankAPI {
}
