package designpatterns.adapter.thirdparty.yesbank;

public class YesBankAPI {
}
